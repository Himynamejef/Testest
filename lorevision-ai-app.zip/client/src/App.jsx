import { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [prompt, setPrompt] = useState('');
  const [lore, setLore] = useState('');
  const [prices, setPrices] = useState({});

  const generateLore = async () => {
    const res = await axios.post('http://localhost:5000/api/generate-lore', { prompt });
    setLore(res.data.text.trim());
  };

  const fetchPrices = async () => {
    const res = await axios.get('http://localhost:5000/api/market-data');
    setPrices(res.data);
  };

  useEffect(() => {
    fetchPrices();
    const interval = setInterval(fetchPrices, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen p-6 bg-gray-900 text-white">
      <h1 className="text-3xl font-bold mb-4">LoreVision AI</h1>
      <div className="mb-4">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe your character or world..."
          className="w-full p-2 text-black"
        />
        <button
          onClick={generateLore}
          className="mt-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded"
        >
          Generate Lore
        </button>
      </div>
      {lore && (
        <div className="bg-gray-800 p-4 rounded">
          <h2 className="text-xl font-semibold mb-2">Generated Lore:</h2>
          <p>{lore}</p>
        </div>
      )}
      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-2">Crypto Prices (USD):</h2>
        <ul>
          <li>Solana (SOL): ${prices.solana?.usd}</li>
          <li>Ethereum (ETH): ${prices.ethereum?.usd}</li>
          <li>Binance Coin (BNB): ${prices.binancecoin?.usd}</li>
        </ul>
      </div>
    </div>
  );
}

export default App;