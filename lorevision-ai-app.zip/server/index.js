const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;

app.post('/api/generate-lore', async (req, res) => {
  const { prompt } = req.body;
  try {
    const response = await axios.post(
      'https://api.openai.com/v1/completions',
      {
        model: 'text-davinci-003',
        prompt,
        max_tokens: 300,
      },
      {
        headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      }
    );
    res.json({ text: response.data.choices[0].text });
  } catch {
    res.status(500).send('Error generating lore');
  }
});

app.get('/api/market-data', async (_, res) => {
  try {
    const response = await axios.get(
      'https://api.coingecko.com/api/v3/simple/price?ids=solana,ethereum,binancecoin&vs_currencies=usd'
    );
    res.json(response.data);
  } catch {
    res.status(500).send('Error fetching market data');
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));